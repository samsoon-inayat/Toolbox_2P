%Chapter 20 - Matlab for Neuroscientists 2e
%Example Book Code
%Nov 15, 2013

%Figure 20.1 makes use of a merged dataset created from 
%training data in Chapter 17 and the test data from Chapter 21.
%Move the data from those chapters to the current directory
%to create a merged dataset with the code below

%If merged dataset does not exist, creat it
if exist('Chap20_DataMerged.mat','file')==0
    %Check to see if Chapter 17 and Chapter 21 data available
    if exist('Chap17_Data.mat','file')==2 && exist('Chap21_Data.mat','file')==2
        disp('Merging Chapter 17 and Chapter 21 datasets')
        load Chap17_Data
        direction2=direction;
        go2=go;
        instruction2=instruction;
        unit2=unit;

        load Chap21_Data
        instruction=[instruction; instruction2];
        go=[go; go2];
        direction=[direction; direction2];
        for i =1:143
            unit(i).times=[unit(i).times; unit2(i).times];
        end
        clear instruction2 direction2 go2 unit2
        save Chap20_DataMerged
    else
        disp('Add Chap17_Data and Chap21_Data to current directory to create a merged dataset for Figure 20.1')
    end
end

if(exist('Chap20_DataMerged.mat','file')==2)
    disp('Plotting from merged dataset')
    %similar to Figure 20.1, left panel
    Chap20_RasterPlot(16)

    %similar to Figure 20.1, right panel
    Chap20_PETH(16)
end

%%

load Chap20_Data
%Pages 319-320
trialNum=1;
binned=hist(trial(trialNum).spikeTimes,[0:.001:1]);

sigma = .015; %Standard deviation of the kernel 5 15 ms
edges=[-3*sigma:.001:3*sigma]; %Time ranges form -3*st. dev. to 3*st. dev.
kernel = normpdf(edges,0,sigma); %Evaluate the Gaussian kernel
kernel = kernel*.001; %Multiply by bin width so the probabilities sum to 1
s=conv(binned,kernel); %Convolve spike data with the kernel
center = ceil(length(edges)/2); %Find the index of the kernel center
s=s(center:1000+center-1); %Trim out the relevant portion of the spike density

%%
%Figure 20.2 (code not in book)
figure
t=trial(trialNum).spikeTimes;
edges2=[0:.001:1];
plot(edges2(1:length(s)),s)
hold on
a=-.01;
b=-0.02;
for i=1:length(t)
    line([t(i) t(i)],[a b])
end
y=ylim;
axis([-0.1 1.1 -0.03 y(2)+0.01])
title(['Spike Density Function for Trial #' num2str(trialNum)])
xlabel('Time (s)')
%%
%Page 321
%Table 20.1
for i=1:8                       %Loop over all directions.
    ind=find(direction==i);     %Find trials in same direction
    %Bin firing rate R into low, medium, high
    table(:,i)=histc(R(ind),[0 19.5 30 100]);
end
disp('')
disp('Table 20.1')
disp(table)

%Table 20.2
table2=table/315;
disp('')
disp('Table 20.2')
disp(table2)

%%
%Calculate information of the neuron (code not in book)
pSR=table2(1:3,:); %trim out zeros
pS=sum(pSR);
pR=sum(pSR');

temp=zeros(3,8);
for i=1:3
    for j=1:8
        if(pSR(i,j)~=0)
            temp(i,j)=pSR(i,j)*log2(pSR(i,j)/(pR(i).*pS(j)));
        end
    end
end
infoNeuron= sum(sum(temp))
%%
%Page 324
%Similar to Table 20.3 
%this is randomly generated, so actual values will vary
edges=[0:24]/24; %Bin edges for each table entry
data=rand(24,1); %Generate 24 random values between 0 and 1
count = histc(data,edges); %Count how many fall in the bin edges
count=count(1:24); %Ignore the last value (counts values equal to 1).
count=reshape(count,3,8); %Reformat the table.
disp('')
disp('Table 20.3')
disp(count)

%Similar to Table 20.4 (code not in book)
data=rand(315,1); %Generate 24 random values between 0 and 1
count2 = histc(data,edges); %Count how many fall in the bin edges
count2=count2(1:24); %Ignore the last value (counts values equal to 1).
count2=reshape(count2,3,8); %Reformat the table.
disp('')
disp('Table 20.4')
disp(count2)

%Page 325
x=rand(315,1); %Vector of 315 random numbers between 0 and 1
[temp ind]=sort(x); %Sort random numbers and keep the indices in vector "ind"
dirSh=direction(ind); %Use "ind" to randomly shuffle the vector of stimuli "dir"

%Similar to Table 20.5 (code not in Book)
for i=1:8                       %Loop over all directions.
    ind=find(dirSh==i);     %Find trials in same direction
    %Bin firing rate R into low, medium, high
    table3(:,i)=histc(R(ind),[0 19.5 30 100]);
end
disp('')
disp('Table 20.5')
disp(table3)

%%
%Calculate information of the neuron with a shuffled stimulus
%(code not in book)
pSR=table2(1:3,:)/315; %trim out zeros
pS=sum(pSR);
pR=sum(pSR');

temp=zeros(3,8);
for i=1:3
    for j=1:8
        if(pSR(i,j)~=0)
            %use if statement to avoid calculating 0*log2(0)           
            temp(i,j)=pSR(i,j)*log2(pSR(i,j)/(pR(i).*pS(j)));
        end
    end
end
infoSh= sum(sum(temp))
